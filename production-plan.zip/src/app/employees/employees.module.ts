
import { NgModule } from '@angular/core';
import { RouterModule} from '@angular/router';
import { SharedModule } from '../shared/shared.module';
import { EmployeeFormComponent } from './employee-form/employee-form.component';
import { EmployeeListComponent } from './employee-list/employee-list.component';


@NgModule({
    imports: [
        SharedModule,
        RouterModule.forChild([
            { path: 'employees', component: EmployeeListComponent},
            { path: 'employees/new', component: EmployeeFormComponent}
        ])
    ],
    declarations:[
        EmployeeFormComponent,
        EmployeeListComponent
       
    ]
})
export class EmployeesModule{}