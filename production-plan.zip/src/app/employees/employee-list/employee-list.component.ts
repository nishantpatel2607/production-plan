import { ActivatedRoute, Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {
  pageTitle: string = "Employees";
  constructor(private activeRoute: ActivatedRoute, private route: Router) { }

  ngOnInit() {
  }

  newEmployee(){
    this.route.navigate(['employees/new']);
  }
}
