
export interface IMachine {
    id: number;
    machineSrNo: string;
    orientation: string;
    shape: string;
    doorType: string;
    machineType: string; 
}