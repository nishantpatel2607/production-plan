
export interface IEmployee{
    id: number;
    firstName: string;
    lastName: string;
    designation: string;
    username: string;
    password: string;
    marking: boolean;
    cuttingShearing: boolean;
    sheetBending: boolean;
    pipeBending: boolean;
    straightening: boolean;
    gauging: boolean;
    pipeFitting: boolean;
    insulation: boolean;
    testing: boolean;
    fittingAssembly: boolean;
    filletWeld: boolean;
    buttWeld: boolean;
    rootWeld: boolean;
    backChipping: boolean;
    tagWeld: boolean;
    edgeWeld: boolean;
    pipeWeld: boolean;
    cleaning: boolean;
    packing: boolean;
    handling: boolean;
    filing: boolean;
    grinding: boolean;
    drilling: boolean;
    tapping: boolean;
    hacksawCutting: boolean;
    painting: boolean;
    helperTagWeld: boolean;
    buffer: boolean;

}