export interface IDesignation{
    id: number;
    title: string;
}