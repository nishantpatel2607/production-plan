import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'machine-form',
  templateUrl: './machine-form.component.html',
  styleUrls: ['./machine-form.component.css']
})
export class MachineFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
