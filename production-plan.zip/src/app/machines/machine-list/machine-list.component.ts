

import { ActivatedRoute, Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

import { IMachine } from '../../model/machine';
import { PagerService} from '../../core/services/pager.service';
import { MachineService } from '../../core/services/machine.service';

@Component({
  selector: 'machine-list',
  templateUrl: './machine-list.component.html',
  styleUrls: ['./machine-list.component.css']
})
export class MachineListComponent implements OnInit {
  pageTitle: string = "Machines";

  machines: IMachine[];
  errorMessage: string;

  pager: any = {};
  pagedItems: any[];

  constructor(private activeRoute: ActivatedRoute, 
    private route: Router, 
    private machineService: MachineService,
    private pagerService: PagerService) { }

  ngOnInit() {
    this.machineService.getMachines()
      .subscribe(machines => this.machines = machines,
          error => this.errorMessage = <any>error);
  }

  newMachine(){
    this.route.navigate(['machines/new']);
  }

  setPage(page: number) {
    if (page < 1 || page > this.pager.totalPages) {
        return;
    }

    // get pager object from service
    this.pager = this.pagerService.getPager(this.machines.length, page);

    // get current page of items
    this.pagedItems = this.machines.slice(this.pager.startIndex, this.pager.endIndex + 1);
}

}
